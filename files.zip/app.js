// Utility functions for local storage
function getTodos() {
  return JSON.parse(localStorage.getItem("todos") || "[]");
}

function saveTodos(todos) {
  localStorage.setItem("todos", JSON.stringify(todos));
}

// Render the to-do list
function renderTodos() {
  const todoList = document.getElementById("todo-list");
  todoList.innerHTML = "";

  const todos = getTodos();
  todos.forEach((todo, idx) => {
    const li = document.createElement("li");
    li.className = "todo-item";

    const span = document.createElement("span");
    span.className = "todo-title" + (todo.completed ? " completed" : "");
    span.textContent = todo.title;
    span.addEventListener("click", () => toggleTodo(idx));

    const btn = document.createElement("button");
    btn.className = "delete-btn";
    btn.textContent = "✕";
    btn.title = "Delete";
    btn.addEventListener("click", () => deleteTodo(idx));

    li.appendChild(span);
    li.appendChild(btn);

    todoList.appendChild(li);
  });
}

// Add new to-do
document.getElementById("todo-form").addEventListener("submit", function(e) {
  e.preventDefault();
  const input = document.getElementById("todo-input");
  const title = input.value.trim();
  if (title) {
    const todos = getTodos();
    todos.push({ title, completed: false });
    saveTodos(todos);
    input.value = "";
    renderTodos();
  }
});

// Toggle completion
function toggleTodo(idx) {
  const todos = getTodos();
  todos[idx].completed = !todos[idx].completed;
  saveTodos(todos);
  renderTodos();
}

// Delete to-do
function deleteTodo(idx) {
  const todos = getTodos();
  todos.splice(idx, 1);
  saveTodos(todos);
  renderTodos();
}

// Initial render
renderTodos();